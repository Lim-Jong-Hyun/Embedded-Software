#include "opendefs.h"
#include "cteam.h"
#include "opencoap.h"
#include "packetfunctions.h"
#include "openqueue.h"
#include "cButton.h"
#include "idmanager.h"
#include "IEEE802154E.h"

//case_num에 들어가 switch문을 작동시킬 상수.
#define SEUNGJOO 1
#define JONGHYUN 2
#define SUNGMIN 3
#define SANGHO 4

static const uint8_t ipAddr_Server[] = {0xaa, 0xaa, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02};
cteam_vars_t cteam_vars;
const uint8_t cteam_path0[] = "team";

owerror_t cteam_receive(OpenQueueEntry_t* msg, coap_header_iht* coap_header, coap_option_iht* coap_options);
void cteam_sendDone(OpenQueueEntry_t* msg, owerror_t error);
void seungjoo(void);
void jonghyun(void);
void sungmin(void);
void sangho(void);
void cb_btn(void);
void cteam_push(void);

void cteam_init(){
  cteam_vars.desc.path0len = sizeof(cteam_path0)-1;
  cteam_vars.desc.path0val = (uint8_t*)(&cteam_path0);
  cteam_vars.desc.path1len = 0;
  cteam_vars.desc.path1val = NULL;
  cteam_vars.desc.componentID = COMPONENT_CTEAM;
  cteam_vars.desc.callbackRx = &cteam_receive;
  cteam_vars.desc.callbackSendDone = &cteam_sendDone;

  btn_setCallbacks(cb_btn);
  cteam_vars.timerId = opentimers_start(3000, TIMER_PERIODIC, TIME_MS, cteam_push);
  opencoap_register(&cteam_vars.desc);
}

void cteam_sendDone(OpenQueueEntry_t* msg, owerror_t error){
  openqueue_freePacketBuffer(msg);
}

owerror_t cteam_receive(OpenQueueEntry_t* msg, coap_header_iht* coap_header, coap_option_iht* coap_options){
  owerror_t outcome;
  int len = 0;
  int case_num = 0;
  int val = 0;
  char str[100] = "";
  switch(coap_header->Code){
    case COAP_CODE_REQ_GET:
    msg->payload = &(msg->packet[127]);
    msg->length = 0;
    packetfunctions_reserveHeaderSize(msg, 1);
    msg->payload[0] = COAP_PAYLOAD_MARKER;
    coap_header->Code = COAP_CODE_RESP_CONTENT;
    outcome = E_SUCCESS;
    break;

    case COAP_CODE_REQ_PUT:

    len = msg -> length;
    memcpy(str,msg->payload,len);

    // packet payload를 reset 시키는 과정
    msg->payload = &(msg->packet[127]);
    msg->length = 0;


    len = strlen(str);
    packetfunctions_reserveHeaderSize(msg,len);
    memcpy(msg->payload,str,len);

    if(!strcmp(str, "seungjoo")) case_num = SEUNGJOO;
    else if(!strcmp(str, "jonghyun")) case_num = JONGHYUN;
    else if(!strcmp(str, "sungmin")) case_num = SUNGMIN;
    else if(!strcmp(str, "sangho")) case_num = SANGHO;
    else if(!strcmp(str,"ledoff")) case_num = 10;
    else case_num=0;


    switch(case_num){
      case SEUNGJOO:
      seungjoo();
      break;

      case JONGHYUN:
      jonghyun();
      break;

      case SUNGMIN:
      sungmin();
      break;

      case 0:
      leds_all_on();
      break;
      case 10:
      leds_all_off();
      break;

      case SANGHO:
      sangho();
      break;

      default:
        leds_all_off();
      }


    packetfunctions_reserveHeaderSize(msg, 1);
    msg->payload[0] = COAP_PAYLOAD_MARKER;

    coap_header->Code = COAP_CODE_RESP_CHANGED;
    outcome = E_SUCCESS;
    break;

    default:
    outcome = E_FAIL;
    break;
  }
  return outcome;
}

void cb_btn(){  //버튼 누르면 호출되는 함수.
  leds_error_toggle();
}

void cteam_push(){
  OpenQueueEntry_t* pkt;
  owerror_t outcome;
  uint8_t numOptions;

  if(ieee154e_isSynch()==FALSE) return;

  if(idmanager_getIsDAGroot()){
    opentimers_stop(cteam_vars.timerId);
    return;
  }

  pkt = openqueue_getFreePacketBuffer(COMPONENT_CTEAM);
  if(pkt==NULL){
    openserial_printError(
      COMPONENT_CTEAM,
      ERR_NO_FREE_PACKET_BUFFER,
      (errorparameter_t)0,
      (errorparameter_t)0
    );
    openqueue_freePacketBuffer(pkt);
    return;
  }
    pkt->creator = COMPONENT_CTEAM;
    pkt->owner = COMPONENT_CTEAM;

    numOptions = 0;
	
	packetfunctions_reserveHeaderSize(pkt,1);
    pkt->payload[0] = leds_sync_isOn();
	
	packetfunctions_reserveHeaderSize(pkt,1);
    pkt->payload[0] = leds_radio_isOn();
	
    packetfunctions_reserveHeaderSize(pkt,1);
    pkt->payload[0] = leds_error_isOn();

	
    packetfunctions_reserveHeaderSize(pkt,1);
    pkt->payload[0] = COAP_PAYLOAD_MARKER;

    packetfunctions_reserveHeaderSize(pkt, sizeof(cteam_path0)-1);
    memcpy(pkt->payload, cteam_path0,sizeof(cteam_path0)-1);
    packetfunctions_reserveHeaderSize(pkt,1);
    pkt->payload[0] = (COAP_OPTION_NUM_URIPATH)<<4 | 3;
    numOptions++;

    pkt ->l4_destination_port = 7654;
    pkt ->l3_destinationAdd.type = ADDR_128B;
    memcpy(&pkt ->l3_destinationAdd.addr_128b[0],&ipAddr_Server,16);

    outcome  = opencoap_send(
      pkt,
      COAP_TYPE_NON,
      COAP_CODE_REQ_POST,
      numOptions,
      &cteam_vars.desc);
    if(outcome == E_FAIL){
      openqueue_freePacketBuffer(pkt);
    }
    return;
}


void sungmin(){
	volatile uint16_t delay;
	int i, count = 5;

	for(i = 0; i<=count; i++){
		leds_error_toggle();
		for (delay=0xffff;delay>0;delay--); // 5번 껐다 켜졌다를 반복
	}

}
void jonghyun(){
  int i=0;
  volatile uint16_t delay;

  for(i=0;i<5;i++){
    leds_error_on();
    for (delay=0xffff;delay>0;delay--);
    leds_error_off();

    leds_sync_on();
    for (delay=0xffff;delay>0;delay--);
    leds_sync_off();
  }
}
void seungjoo(){
  volatile uint16_t delay;

  leds_all_on(); //all on
  for(delay=0xffff ; delay>0 ; delay--);
  leds_error_off();
  for(delay=0xffff ; delay>0 ; delay--);
  leds_radio_off();
  for(delay=0xffff ; delay>0 ; delay--);
  leds_sync_off();
}
void sangho(){

  volatile uint16_t delay;
  int i=0;
  for (i = 0; i <= 3; i++) {
    leds_all_toggle();
    for (delay = 0xffff; delay>0; delay--);
  }
}
