#ifndef __CTEAM_H
#define __CTEAM_H

#include "opencoap.h"

typedef struct{
  coap_resource_desc_t desc;
  opentimer_id_t timerId;
}cteam_vars_t;

void cteam_init(void);
#endif
